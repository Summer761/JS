function inicio() {
    let nome = window.prompt('Qual é o seu nome')
    window.alert(`olá, ${nome} é um prazer ver voce aqui !`)
}
function inicio2() {
    let nome2 = window.prompt('Qual a sua Idade ?')
    window.alert(`olá, voce tem ${nome2} anos de idade `)
}